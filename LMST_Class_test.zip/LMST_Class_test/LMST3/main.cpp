#include <iostream>
#include <cstring>
#include <math.h>
#include <stdio.h>
#include <algorithm>
#include <iomanip>
#include <random>
#include <ctime>
#define Pi 3.1415
using namespace std;
 
int i=0, j=0, k=0, K=1;
int n = 0, m = 0; //n: number of nodes  m:number of node-node links
double map[100][100];
double min_value = 0;
double r[6][6] = {0};
double position1 = 0, position2 = 0, position3 = 0, position4 = 0, position5 = 0, position = 0, d_array[20] = {0}, Pos[6][11], Min_Value[6][11];
double distance1[5],distance2[5],distance3[5],distance4[5],distance5[5];
double p_x1[10],p_y1[10],p_x2[10],p_y2[10],p_x3[10],p_y3[10],p_x4[10],p_y4[10],p_x5[10],p_y5[10];
double p_x11, p_y11, p_x21, p_y21, p_x31, p_y31, p_x41, p_y41, p_x51, p_y51;
double p_x[6], p_y[6];
double d_x,d_y;
double weight[10][10],total[10];
double n_i[10],m_i[10],N_1[10],M_1[10],N_2[10],M_2[10],N_3[10],M_3[10],N_4[10],M_4[10],N_5[10],M_5[10];
double cos_value[10], sin_value[10];
double angle_x1,angle_y1,angle_x2,angle_y2,angle_x3,angle_y3,angle_x4,angle_y4;
double theta1[20][20],theta2[20][20],C_X1[40],C_Y1[40],C_X2[40],C_Y2[40];
double angle_min1,angle_max1,angle_min2,angle_max2;
double Angle_Max1[20][20],Angle_Min1[20][20],Angle_Max2[20][20],Angle_Min2[20][20];
double interval1[10][10],interval2[10][10],Distance1[21][11],Distance2[21][11],Distance3[21][11],Distance4[21][11],Distance5[21][11];
double center_point_x1[20][20] = {0},center_point_y1[20][20] = {0},center_point_x2[20][20] = {0},center_point_y2[20][20] = {0};
double point_x1, point_x2, point_y1, point_y2;
double X[6] = {0, 0.7254, 0.1755, 0.8391, 0.7393, 0.3104};
double Y[6] = {0, 0.2373, 0.5699, 0.2775, 0.6418, 0.6508};
double x_target[6] = {0, 5.3782, 5.5610, 5.8799, 5.9165, 5.5124};
double y_target[6] = {0, 5.9729, 5.2516, 5.6718, 5.2155, 5.9351};

class LMST
{
    public:
        int insect(double x1, double y1,double radius1, double x2, double y2, double radius2);
        void array_change(int n, double array[][11]);
        void angle_change(double &array1, double &array2);
        void prim();
        void pos_number1(int number, double (&pos_x)[6], double (&pos_y)[6]);
        void pos_number2(int number, double (&pos_x)[6], double (&pos_y)[6]);
        void pos_number3(int number, double (&pos_x)[6], double (&pos_y)[6]);
        void pos_number4(int number, double (&pos_x)[6], double (&pos_y)[6]);
        void pos_number5(int number, double (&pos_x)[6], double (&pos_y)[6]);
    private:
        int double_equals(double const a, double const b);
        double distance_sqr(double x1, double y1, double x2, double y2);
        double distance(double x1, double y1, double x2, double y2);
        bool cmp(int a,int b);
};

inline int LMST::double_equals(double const a, double const b)
{
    static const double ZERO = 1e-9;
    return fabs(a - b) < ZERO;
}

inline double LMST::distance_sqr(double x1, double y1, double x2, double y2)
{
    return (x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2);  //square of distance between two center points
}

inline double LMST::distance(double x1, double y1, double x2, double y2)
{
    return sqrt(distance_sqr(x1,y1,x2,y2));     //distance between two center points
}

inline bool LMST::cmp(int a,int b)
{
    return a<b;
}

void LMST::array_change(int n, double array[][11])
{
    for(j=1;j<=20;j++)
    {
        d_array[j] = array[j][n];
    }
    min_value = *min_element(d_array+1,d_array+21);
    position = min_element(d_array+1,d_array+21)-d_array;
}

void LMST::angle_change(double &array1, double &array2) //array1[] - > angle_y[]  array2[] -> angle_x[]
{
    if(array1<0)
    {
        if(array2>90)
        {
            array2 = 360 - array2;
            array1 = 180 - array1;
        }
        else
        {
            array2 = 360 - array2;
            array1 = 360 + array1;
        }
    }
    else
    {
        if(array2>90)
        {
            array1 = array2;
        }
    }
}


void LMST::prim()  //Minimum Spanning Tree (prim algorithm)
{
    cout<<"prim:"<<endl;
    double lowcost[101];  //lowcost[i] takes the minimum weight from each node to the i node in the tree => minimum weight
    int closest[101];  //closest[i] takes the node which has the minimum weight to node i => node number
    bool s[101];
    s[1] = true;  //choose 1 as root
    int i,j,k;
    for(i=2;i<=n;i++)  //initialize lowcost and s
    {
        lowcost[i] = map[1][i];
        s[i] = false;
        closest[i] = 1;
    }
    double min;
    for(i=1;i<n;i++)  //minimum spanning tree only has n-1 links
    {
        min = 100000;
        k = 1;
        for(j=2;j<=n;j++)  //find minimum link
        {
            if((lowcost[j]<min)&&(!s[j]))
            {
                min = lowcost[j];
                k = j;
            }
        }
        cout<<closest[k]<<","<<k<<" "<<"weight:"<<min<<endl;
        
        if(closest[k]>k)
        {
            n_i[i] = k;
            m_i[i] = closest[k];
        }
        else
        {
            n_i[i] = closest[k];
            m_i[i] = k;
        }
        
        s[k] = true;
        for(j=2;j<=n;j++)
        {
            if((map[k][j]<lowcost[j])&&(!s[j]))  //if new node to node j has smaller weight, it will replace the original node
            {
                lowcost[j] = map[k][j];
                closest[j] = k;
            }
        }
    }
}

void LMST::pos_number1(int number, double (&pos_x)[6], double (&pos_y)[6])
{
    if(number > 1)
    {
        for(i=1;i<=number;i++)
        {
            if(M_1[i] == 2)
            {
                array_change(1,Distance1);
                Pos[1][i] = position;
                Min_Value[1][i] = min_value;
                if(position > 10)
                {
                    p_x1[i] = X[2] + 1*cos(theta2[(int)position-10][1]*Pi/180);
                    p_y1[i] = Y[2] + 1*sin(theta2[(int)position-10][1]*Pi/180);
                    distance1[i] = sqrt(pow(p_x1[i]-x_target[1],2)+pow(p_y1[i]-y_target[1],2));
                }
                else
                {
                    p_x1[i] = X[1] + 1*cos(theta1[(int)position][1]*Pi/180);
                    p_y1[i] = Y[1] + 1*sin(theta1[(int)position][1]*Pi/180);
                    distance1[i] = sqrt(pow(p_x1[i]-x_target[1],2)+pow(p_y1[i]-y_target[1],2));
                }
            }
            else if(M_1[i] == 3)
            {
                array_change(2,Distance1);
                Pos[1][i] = position;
                Min_Value[1][i] = min_value;
                if(position > 10)
                {
                    p_x1[i] = X[3] + 1*cos(theta2[(int)position-10][2]*Pi/180);
                    p_y1[i] = Y[3] + 1*sin(theta2[(int)position-10][2]*Pi/180);
                    distance1[i] = sqrt(pow(p_x1[i]-x_target[1],2)+pow(p_y1[i]-y_target[1],2));
                }
                else
                {
                    p_x1[i] = X[1] + 1*cos(theta1[(int)position][2]*Pi/180);
                    p_y1[i] = Y[1] + 1*sin(theta1[(int)position][2]*Pi/180);
                    distance1[i] = sqrt(pow(p_x1[i]-x_target[1],2)+pow(p_y1[i]-y_target[1],2));
                }
            }
            else if(M_1[i] == 4)
            {
                array_change(3,Distance1);
                Pos[1][i] = position;
                Min_Value[1][i] = min_value;
                if(position > 10)
                {
                    p_x1[i] = X[4] + 1*cos(theta2[(int)position-10][3]*Pi/180);
                    p_y1[i] = Y[4] + 1*sin(theta2[(int)position-10][3]*Pi/180);
                    distance1[i] = sqrt(pow(p_x1[i]-x_target[1],2)+pow(p_y1[i]-y_target[1],2));
                }
                else
                {
                    p_x1[i] = X[1] + 1*cos(theta1[(int)position][3]*Pi/180);
                    p_y1[i] = Y[1] + 1*sin(theta1[(int)position][3]*Pi/180);
                    distance1[i] = sqrt(pow(p_x1[i]-x_target[1],2)+pow(p_y1[i]-y_target[1],2));
                }
            }
            else if(M_1[i] == 5)
            {
                array_change(4,Distance1);
                Pos[1][i] = position;
                Min_Value[1][i] = min_value;
                if(position > 10)
                {
                    p_x1[i] = X[5] + 1*cos(theta2[(int)position-10][4]*Pi/180);
                    p_y1[i] = Y[5] + 1*sin(theta2[(int)position-10][4]*Pi/180);
                    distance1[i] = sqrt(pow(p_x1[i]-x_target[1],2)+pow(p_y1[i]-y_target[1],2));
                }
                else
                {
                    p_x1[i] = X[1] + 1*cos(theta1[(int)position][4]*Pi/180);
                    p_y1[i] = Y[1] + 1*sin(theta1[(int)position][4]*Pi/180);
                    distance1[i] = sqrt(pow(p_x1[i]-x_target[1],2)+pow(p_y1[i]-y_target[1],2));
                }
            }
        }
        position1 = min_element(distance1+1,distance1+1+number)-distance1;
        pos_x[1]= p_x1[(int)position1];
        pos_y[1]= p_y1[(int)position1];
    }
    else
    {
        if(M_1[1] == 2)
        {
            array_change(1,Distance1);
            Pos[1][1] = position;
            Min_Value[1][1] = min_value;
            if(position > 10)
            {
                p_x11 = X[2] + 1*cos(theta2[(int)position-10][1]*Pi/180);
                p_y11 = Y[2] + 1*sin(theta2[(int)position-10][1]*Pi/180);
            }
            else
            {
                p_x11 = X[1] + 1*cos(theta1[(int)position][1]*Pi/180);
                p_y11 = Y[1] + 1*sin(theta1[(int)position][1]*Pi/180);
            }
        }
        else if(M_1[1] == 3)
        {
            array_change(2,Distance1);
            Pos[1][1] = position;
            Min_Value[1][1] = min_value;
            if(position > 10)
            {
                p_x11 = X[3] + 1*cos(theta2[(int)position-10][2]*Pi/180);
                p_y11 = Y[3] + 1*sin(theta2[(int)position-10][2]*Pi/180);
            }
            else
            {
                p_x11 = X[1] + 1*cos(theta1[(int)position][2]*Pi/180);
                p_y11 = Y[1] + 1*sin(theta1[(int)position][2]*Pi/180);
            }
        }
        else if(M_1[1] == 4)
        {
            array_change(3,Distance1);
            Pos[1][1] = position;
            Min_Value[1][1] = min_value;
            if(position > 10)
            {
                p_x11 = X[4] + 1*cos(theta2[(int)position-10][3]*Pi/180);
                p_y11 = Y[4] + 1*sin(theta2[(int)position-10][3]*Pi/180);
            }
            else
            {
                p_x11 = X[1] + 1*cos(theta1[(int)position][3]*Pi/180);
                p_y11 = Y[1] + 1*sin(theta1[(int)position][3]*Pi/180);
            }
        }
        else if(M_1[1] == 5)
        {
            array_change(4,Distance1);
            Pos[1][1] = position;
            Min_Value[1][1] = min_value;
            if(position > 10)
            {
                p_x11 = X[5] + 1*cos(theta2[(int)position-10][4]*Pi/180);
                p_y11 = Y[5] + 1*sin(theta2[(int)position-10][4]*Pi/180);
            }
            else
            {
                p_x11 = X[1] + 1*cos(theta1[(int)position][4]*Pi/180);
                p_y11 = Y[1] + 1*sin(theta1[(int)position][4]*Pi/180);
            }
        }
        pos_x[1] = p_x11;
        pos_y[1] = p_y11;
    }
}

void LMST::pos_number2(int number, double (&pos_x)[6], double (&pos_y)[6])
{
    if(number > 1)
    {
        for(i=1;i<=number;i++)
        {
            if(M_2[i] == 3)
            {
                array_change(5,Distance2);
                Pos[2][i] = position;
                Min_Value[2][i] = min_value;
                if(Pos[2][i] > 10)
                {
                    p_x2[i] = X[3] + 1*cos(theta2[(int)Pos[2][i]-10][5]*Pi/180);
                    p_y2[i] = Y[3] + 1*sin(theta2[(int)Pos[2][i]-10][5]*Pi/180);
                    distance2[i] = sqrt(pow(p_x2[i]-x_target[2],2)+pow(p_y2[i]-y_target[2],2));
                }
                else
                {
                    p_x2[i] = X[2] + 1*cos(theta1[(int)Pos[2][i]][5]*Pi/180);
                    p_y2[i] = Y[2] + 1*sin(theta1[(int)Pos[2][i]][5]*Pi/180);
                    distance2[i] = sqrt(pow(p_x2[i]-x_target[2],2)+pow(p_y2[i]-y_target[2],2));
                }
            }
            else if(M_2[i] == 4)
            {
                array_change(6,Distance2);
                Pos[2][i] = position;
                Min_Value[2][i] = min_value;
                if(Pos[2][i] > 10)
                {
                    p_x2[i] = X[4] + 1*cos(theta2[(int)Pos[2][i]-10][6]*Pi/180);
                    p_y2[i] = Y[4] + 1*sin(theta2[(int)Pos[2][i]-10][6]*Pi/180);
                    distance2[i] = sqrt(pow(p_x2[i]-x_target[2],2)+pow(p_y2[i]-y_target[2],2));
                }
                else
                {
                    p_x2[i] = X[2] + 1*cos(theta1[(int)Pos[2][i]][6]*Pi/180);
                    p_y2[i] = Y[2] + 1*sin(theta1[(int)Pos[2][i]][6]*Pi/180);
                    distance2[i] = sqrt(pow(p_x2[i]-x_target[2],2)+pow(p_y2[i]-y_target[2],2));
                }
            }
            else if(M_2[i] == 5)
            {
                array_change(7,Distance2);
                Pos[2][i] = position;
                Min_Value[2][i] = min_value;
                if(Pos[2][i] > 10)
                {
                    p_x2[i] = X[5] + 1*cos(theta2[(int)Pos[2][i]-10][7]*Pi/180);
                    p_y2[i] = Y[5] + 1*sin(theta2[(int)Pos[2][i]-10][7]*Pi/180);
                    distance2[i] = sqrt(pow(p_x2[i]-x_target[2],2)+pow(p_y2[i]-y_target[2],2));
                }
                else
                {
                    p_x2[i] = X[2] + 1*cos(theta1[(int)Pos[2][i]][7]*Pi/180);
                    p_y2[i] = Y[2] + 1*sin(theta1[(int)Pos[2][i]][7]*Pi/180);
                    distance2[i] = sqrt(pow(p_x2[i]-x_target[2],2)+pow(p_y2[i]-y_target[2],2));
                }
            }
            else if(N_2[i] == 1)
            {
                array_change(1,Distance2);
                Pos[2][i] = position;
                Min_Value[2][i] = min_value;
                if(Pos[2][i] > 10)
                {
                    p_x2[i] = X[2] + 1*cos(theta2[(int)Pos[2][i]-10][1]*Pi/180);
                    p_y2[i] = Y[2] + 1*sin(theta2[(int)Pos[2][i]-10][1]*Pi/180);
                    distance2[i] = sqrt(pow(p_x2[i]-x_target[2],2)+pow(p_y2[i]-y_target[2],2));
                }
                else
                {
                    p_x2[i] = X[1] + 1*cos(theta1[(int)Pos[2][i]][1]*Pi/180);
                    p_y2[i] = Y[1] + 1*sin(theta1[(int)Pos[2][i]][1]*Pi/180);
                    distance2[i] = sqrt(pow(p_x2[i]-x_target[2],2)+pow(p_y2[i]-y_target[2],2));
                }
            }
        }
        position2 = min_element(distance2+1,distance2+1+number)-distance2;
        pos_x[2] = p_x2[(int)position2];
        pos_y[2] = p_y2[(int)position2];
    }
    else
    {
        if(M_2[1] == 3)
        {
            array_change(5,Distance2);
            Pos[2][1] = position;
            Min_Value[2][1] = min_value;
            if(Pos[2][1] > 10)
            {
                p_x21 = X[3] + 1*cos(theta2[(int)Pos[2][1]-10][5]*Pi/180);
                p_y21 = Y[3] + 1*sin(theta2[(int)Pos[2][1]-10][5]*Pi/180);
            }
            else
            {
                p_x21 = X[2] + 1*cos(theta1[(int)Pos[2][1]][5]*Pi/180);
                p_y21 = Y[2] + 1*sin(theta1[(int)Pos[2][1]][5]*Pi/180);
            }
        }
        else if(M_2[1] == 4)
        {
            array_change(6,Distance2);
            Pos[2][1] = position;
            Min_Value[2][1] = min_value;
            if(Pos[2][1] > 10)
            {
                p_x21 = X[4] + 1*cos(theta2[(int)Pos[2][1]-10][6]*Pi/180);
                p_y21 = Y[4] + 1*sin(theta2[(int)Pos[2][1]-10][6]*Pi/180);
            }
            else
            {
                p_x21 = X[2] + 1*cos(theta1[(int)Pos[2][1]][6]*Pi/180);
                p_y21 = Y[2] + 1*sin(theta1[(int)Pos[2][1]][6]*Pi/180);
            }
        }
        else if(M_2[1] == 5)
        {
            array_change(7,Distance2);
            Pos[2][1] = position;
            Min_Value[2][1] = min_value;
            if(Pos[2][1] > 10)
            {
                p_x21 = X[5] + 1*cos(theta2[(int)Pos[2][1]-10][7]*Pi/180);
                p_y21 = Y[5] + 1*sin(theta2[(int)Pos[2][1]-10][7]*Pi/180);
            }
            else
            {
                p_x21 = X[2] + 1*cos(theta1[(int)Pos[2][1]][7]*Pi/180);
                p_y21 = Y[2] + 1*sin(theta1[(int)Pos[2][1]][7]*Pi/180);
            }
        }
        else if(N_2[1] == 1)
        {
            array_change(1,Distance2);
            Pos[2][1] = position;
            Min_Value[2][1] = min_value;
            if(Pos[2][1] > 10)
            {
                p_x21 = X[2] + 1*cos(theta2[(int)Pos[2][1]-10][1]*Pi/180);
                p_y21 = Y[2] + 1*sin(theta2[(int)Pos[2][1]-10][1]*Pi/180);
            }
            else
            {
                p_x21 = X[1] + 1*cos(theta1[(int)Pos[2][1]][1]*Pi/180);
                p_y21 = Y[1] + 1*sin(theta1[(int)Pos[2][1]][1]*Pi/180);
            }
        }
        pos_x[2] = p_x21;
        pos_y[2] = p_y21;
    }
}

void LMST::pos_number3(int number, double (&pos_x)[6], double (&pos_y)[6])
{
    if(number > 1)
          {
              for(i=1;i<=number;i++)
              {
                  if(N_3[i] == 1)
                  {
                      array_change(2,Distance3);
                      Pos[3][i] = position;
                      Min_Value[3][i] = min_value;
                      if(position > 10)
                      {
                          p_x3[i] = X[3] + 1*cos(theta2[(int)position-10][2]*Pi/180);
                          p_y3[i] = Y[3] + 1*sin(theta2[(int)position-10][2]*Pi/180);
                          distance3[i] = sqrt(pow(p_x3[i]-x_target[3],2)+pow(p_y3[i]-y_target[3],2));
                      }
                      else
                      {
                          p_x3[i] = X[1] + 1*cos(theta1[(int)position][2]*Pi/180);
                          p_y3[i] = Y[1] + 1*sin(theta1[(int)position][2]*Pi/180);
                          distance3[i] = sqrt(pow(p_x3[i]-x_target[3],2)+pow(p_y3[i]-y_target[3],2));
                      }
                  }
                  else if(N_3[i] == 2)
                  {
                      array_change(5,Distance3);
                      Pos[3][i] = position;
                      Min_Value[3][i] = min_value;
                      if(position > 10)
                      {
                          p_x3[i] = X[3] + 1*cos(theta2[(int)position-10][5]*Pi/180);
                          p_y3[i] = Y[3] + 1*sin(theta2[(int)position-10][5]*Pi/180);
                          distance3[i] = sqrt(pow(p_x3[i]-x_target[3],2)+pow(p_y3[i]-y_target[3],2));
                      }
                      else
                      {
                          p_x3[i] = X[2] + 1*cos(theta1[(int)position][5]*Pi/180);
                          p_y3[i] = Y[2] + 1*sin(theta1[(int)position][5]*Pi/180);
                          distance3[i] = sqrt(pow(p_x3[i]-x_target[3],2)+pow(p_y3[i]-y_target[3],2));
                      }
                  }
                  else if(M_3[i] == 4)
                  {
                      array_change(8,Distance3);
                      Pos[3][i] = position;
                      Min_Value[3][i] = min_value;
                      if(position > 10)
                      {
                          p_x3[i] = X[4] + 1*cos(theta2[(int)position-10][8]*Pi/180);
                          p_y3[i] = Y[4] + 1*sin(theta2[(int)position-10][8]*Pi/180);
                          distance3[i] = sqrt(pow(p_x3[i]-x_target[3],2)+pow(p_y3[i]-y_target[3],2));
                      }
                      else
                      {
                          p_x3[i] = X[3] + 1*cos(theta1[(int)position][8]*Pi/180);
                          p_y3[i] = Y[3] + 1*sin(theta1[(int)position][8]*Pi/180);
                          distance3[i] = sqrt(pow(p_x3[i]-x_target[3],2)+pow(p_y3[i]-y_target[3],2));
                      }
                  }
                  else if(M_3[i] == 5)
                  {
                      array_change(9,Distance3);
                      Pos[3][i] = position;
                      Min_Value[3][i] = min_value;
                      if(position > 10)
                      {
                          p_x3[i] = X[5] + 1*cos(theta2[(int)position-10][9]*Pi/180);
                          p_y3[i] = Y[5] + 1*sin(theta2[(int)position-10][9]*Pi/180);
                          distance3[i] = sqrt(pow(p_x3[i]-x_target[3],2)+pow(p_y3[i]-y_target[3],2));
                      }
                      else
                      {
                          p_x3[i] = X[3] + 1*cos(theta1[(int)position][9]*Pi/180);
                          p_y3[i] = Y[3] + 1*sin(theta1[(int)position][9]*Pi/180);
                          distance3[i] = sqrt(pow(p_x3[i]-x_target[3],2)+pow(p_y3[i]-y_target[3],2));
                      }
                  }
              }
              position3 = min_element(distance3+1,distance3+1+number)-distance3;
              pos_x[3] = p_x3[(int)position3];
              pos_y[3] = p_y3[(int)position3];
          }
          else
          {
              if(N_3[1] == 1)
              {
                  array_change(2,Distance3);
                  Pos[3][1] = position;
                  Min_Value[3][1] = min_value;
                  if(position > 10)
                  {
                      p_x31 = X[3] + 1*cos(theta2[(int)position-10][2]*Pi/180);
                      p_y31 = Y[3] + 1*sin(theta2[(int)position-10][2]*Pi/180);
                  }
                  else
                  {
                      p_x31 = X[1] + 1*cos(theta1[(int)position][2]*Pi/180);
                      p_y31 = Y[1] + 1*sin(theta1[(int)position][2]*Pi/180);
                  }
              }
              else if(N_3[1] == 2)
              {
                  array_change(5,Distance3);
                  Pos[3][1] = position;
                  Min_Value[3][1] = min_value;
                  if(position > 10)
                  {
                      p_x31 = X[3] + 1*cos(theta2[(int)position-10][5]*Pi/180);
                      p_y31 = Y[3] + 1*sin(theta2[(int)position-10][5]*Pi/180);
                  }
                  else
                  {
                      p_x31 = X[2] + 1*cos(theta1[(int)position][5]*Pi/180);
                      p_y31 = Y[2] + 1*sin(theta1[(int)position][5]*Pi/180);
                  }
              }
              else if(M_3[1] == 4)
              {
                  array_change(8,Distance3);
                  Pos[3][1] = position;
                  Min_Value[3][1] = min_value;
                  if(position > 10)
                  {
                      p_x31 = X[4] + 1*cos(theta2[(int)position-10][8]*Pi/180);
                      p_y31 = Y[4] + 1*sin(theta2[(int)position-10][8]*Pi/180);
                  }
                  else
                  {
                      p_x31 = X[3] + 1*cos(theta1[(int)position][8]*Pi/180);
                      p_y31 = Y[3] + 1*sin(theta1[(int)position][8]*Pi/180);
                  }
              }
              else if(M_3[1] == 5)
              {
                  array_change(9,Distance3);
                  Pos[3][1] = position;
                  Min_Value[3][1] = min_value;
                  if(position > 10)
                  {
                      p_x31 = X[5] + 1*cos(theta2[(int)position-10][9]*Pi/180);
                      p_y31 = Y[5] + 1*sin(theta2[(int)position-10][9]*Pi/180);
                  }
                  else
                  {
                      p_x31 = X[3] + 1*cos(theta1[(int)position][9]*Pi/180);
                      p_y31 = Y[3] + 1*sin(theta1[(int)position][9]*Pi/180);
                  }
              }
              pos_x[3] = p_x31;
              pos_y[3] = p_y31;
          }
}

void LMST::pos_number4(int number, double (&pos_x)[6], double (&pos_y)[6])
{
    if(number > 1)
    {
        for(i=1;i<=number;i++)
        {
            if(N_4[i] == 1)
            {
                array_change(3,Distance4);
                Pos[4][i] = position;
                Min_Value[4][i] = min_value;
                if(position > 10)
                {
                    p_x4[i] = X[4] + 1*cos(theta2[(int)position-10][3]*Pi/180);
                    p_y4[i] = Y[4] + 1*sin(theta2[(int)position-10][3]*Pi/180);
                    distance4[i] = sqrt(pow(p_x4[i]-x_target[4],2)+pow(p_y4[i]-y_target[4],2));
                }
                else
                {
                    p_x4[i] = X[1] + 1*cos(theta1[(int)position][3]*Pi/180);
                    p_y4[i] = Y[1] + 1*sin(theta1[(int)position][3]*Pi/180);
                    distance4[i] = sqrt(pow(p_x4[i]-x_target[4],2)+pow(p_y4[i]-y_target[4],2));
                }
            }
            else if(N_4[i] == 2)
            {
                array_change(6,Distance4);
                Pos[4][i] = position;
                Min_Value[4][i] = min_value;
                if(position > 10)
                {
                    p_x4[i] = X[4] + 1*cos(theta2[(int)position-10][6]*Pi/180);
                    p_y4[i] = Y[4] + 1*sin(theta2[(int)position-10][6]*Pi/180);
                    distance4[i] = sqrt(pow(p_x4[i]-x_target[4],2)+pow(p_y4[i]-y_target[4],2));
                }
                else
                {
                    p_x4[i] = X[2] + 1*cos(theta1[(int)position][6]*Pi/180);
                    p_y4[i] = Y[2] + 1*sin(theta1[(int)position][6]*Pi/180);
                    distance4[i] = sqrt(pow(p_x4[i]-x_target[4],2)+pow(p_y4[i]-y_target[4],2));
                }
            }
            else if(N_4[i] == 3)
            {
                array_change(8,Distance4);
                Pos[4][i] = position;
                Min_Value[4][i] = min_value;
                if(position > 10)
                {
                    p_x4[i] = X[4] + 1*cos(theta2[(int)position-10][8]*Pi/180);
                    p_y4[i] = Y[4] + 1*sin(theta2[(int)position-10][8]*Pi/180);
                    distance4[i] = sqrt(pow(p_x4[i]-x_target[4],2)+pow(p_y4[i]-y_target[4],2));
                }
                else
                {
                    p_x4[i] = X[3] + 1*cos(theta1[(int)position][8]*Pi/180);
                    p_y4[i] = Y[3] + 1*sin(theta1[(int)position][8]*Pi/180);
                    distance4[i] = sqrt(pow(p_x4[i]-x_target[4],2)+pow(p_y4[i]-y_target[4],2));
                }
            }
            else if(M_4[i] == 5)
            {
                array_change(10,Distance4);
                Pos[4][i] = position;
                Min_Value[4][i] = min_value;
                if(position > 10)
                {
                    p_x4[i] = X[5] + 1*cos(theta2[(int)position-10][10]*Pi/180);
                    p_y4[i] = Y[5] + 1*sin(theta2[(int)position-10][10]*Pi/180);
                    distance4[i] = sqrt(pow(p_x4[i]-x_target[4],2)+pow(p_y4[i]-y_target[4],2));
                }
                else
                {
                    p_x4[i] = X[4] + 1*cos(theta1[(int)position][10]*Pi/180);
                    p_y4[i] = Y[4] + 1*sin(theta1[(int)position][10]*Pi/180);
                    distance4[i] = sqrt(pow(p_x4[i]-x_target[4],2)+pow(p_y4[i]-y_target[4],2));
                }
            }
        }
        position4 = min_element(distance4+1,distance4+1+number)-distance4;
        pos_x[4] = p_x4[(int)position4];
        pos_y[4] = p_y4[(int)position4];
    }
    else
    {
        if(N_4[1] == 1)
        {
            array_change(3,Distance4);
            Pos[4][1] = position;
            Min_Value[4][1] = min_value;
            if(position > 10)
            {
                p_x41 = X[4] + 1*cos(theta2[(int)position-10][3]*Pi/180);
                p_y41 = Y[4] + 1*sin(theta2[(int)position-10][3]*Pi/180);
            }
            else
            {
                p_x41 = X[1] + 1*cos(theta1[(int)position][3]*Pi/180);
                p_y41 = Y[1] + 1*sin(theta1[(int)position][3]*Pi/180);
            }
        }
        else if(N_4[1] == 2)
        {
            array_change(6,Distance4);
            Pos[4][1] = position;
            Min_Value[4][1] = min_value;
            if(position > 10)
            {
                p_x41 = X[4] + 1*cos(theta2[(int)position-10][6]*Pi/180);
                p_y41 = Y[4] + 1*sin(theta2[(int)position-10][6]*Pi/180);
            }
            else
            {
                p_x41 = X[2] + 1*cos(theta1[(int)position][6]*Pi/180);
                p_y41 = Y[2] + 1*sin(theta1[(int)position][6]*Pi/180);
            }
        }
        else if(N_4[1] == 3)
        {
            array_change(8,Distance4);
            Pos[4][1] = position;
            Min_Value[4][1] = min_value;
            if(position > 10)
            {
                p_x41 = X[4] + 1*cos(theta2[(int)position-10][8]*Pi/180);
                p_y41 = Y[4] + 1*sin(theta2[(int)position-10][8]*Pi/180);
            }
            else
            {
                p_x41 = X[3] + 1*cos(theta1[(int)position][8]*Pi/180);
                p_y41 = Y[3] + 1*sin(theta1[(int)position][8]*Pi/180);
            }
        }
        else if(M_4[1] == 5)
        {
            array_change(10,Distance4);
            Pos[4][1] = position;
            Min_Value[4][1] = min_value;
            if(position > 10)
            {
                p_x41 = X[5] + 1*cos(theta2[(int)position-10][10]*Pi/180);
                p_y41 = Y[5] + 1*sin(theta2[(int)position-10][10]*Pi/180);
            }
            else
            {
                p_x41 = X[4] + 1*cos(theta1[(int)position][10]*Pi/180);
                p_y41 = Y[4] + 1*sin(theta1[(int)position][10]*Pi/180);
            }
        }
        pos_x[4] = p_x41;
        pos_y[4] = p_y41;
    }
}

void LMST::pos_number5(int number, double (&pos_x)[6], double (&pos_y)[6])
{
    if(number > 1)
          {
              for(i=1;i<=number;i++)
              {
                  if(N_5[i] == 1)
                  {
                      array_change(4,Distance5);
                      Pos[5][i] = position;
                      Min_Value[5][i] = min_value;
                      if(position > 10)
                      {
                          p_x5[i] = X[5] + 1*cos(theta2[(int)position-10][4]*Pi/180);
                          p_y5[i] = Y[5] + 1*sin(theta2[(int)position-10][4]*Pi/180);
                          distance5[i] = sqrt(pow(p_x5[i]-x_target[5],2)+pow(p_y5[i]-y_target[5],2));
                      }
                      else
                      {
                          p_x5[i] = X[1] + 1*cos(theta1[(int)position][4]*Pi/180);
                          p_y5[i] = Y[1] + 1*sin(theta1[(int)position][4]*Pi/180);
                          distance5[i] = sqrt(pow(p_x5[i]-x_target[5],2)+pow(p_y5[i]-y_target[5],2));
                      }
                  }
                  else if(N_5[i] == 2)
                  {
                      array_change(7,Distance5);
                      Pos[5][i] = position;
                      Min_Value[5][i] = min_value;
                      if(position > 10)
                      {
                          p_x5[i] = X[5] + 1*cos(theta2[(int)position-10][7]*Pi/180);
                          p_y5[i] = Y[5] + 1*sin(theta2[(int)position-10][7]*Pi/180);
                          distance5[i] = sqrt(pow(p_x5[i]-x_target[5],2)+pow(p_y5[i]-y_target[5],2));
                      }
                      else
                      {
                          p_x5[i] = X[2] + 1*cos(theta1[(int)position][7]*Pi/180);
                          p_y5[i] = Y[2] + 1*sin(theta1[(int)position][7]*Pi/180);
                          distance5[i] = sqrt(pow(p_x5[i]-x_target[5],2)+pow(p_y5[i]-y_target[5],2));
                      }
                  }
                  else if(N_5[i] == 3)
                  {
                      array_change(9,Distance5);
                      Pos[5][i] = position;
                      Min_Value[5][i] = min_value;
                      if(position > 10)
                      {
                          p_x5[i] = X[5] + 1*cos(theta2[(int)position-10][9]*Pi/180);
                          p_y5[i] = Y[5] + 1*sin(theta2[(int)position-10][9]*Pi/180);
                          distance5[i] = sqrt(pow(p_x5[i]-x_target[5],2)+pow(p_y5[i]-y_target[5],2));
                      }
                      else
                      {
                          p_x5[i] = X[3] + 1*cos(theta1[(int)position][9]*Pi/180);
                          p_y5[i] = Y[3] + 1*sin(theta1[(int)position][9]*Pi/180);
                          distance5[i] = sqrt(pow(p_x5[i]-x_target[5],2)+pow(p_y5[i]-y_target[5],2));
                      }
                  }
                  else if(N_5[i] == 4)
                  {
                      array_change(10,Distance5);
                      Pos[5][i] = position;
                      Min_Value[5][i] = min_value;
                      if(position > 10)
                      {
                          p_x5[i] = X[5] + 1*cos(theta2[(int)position-10][10]*Pi/180);
                          p_y5[i] = Y[5] + 1*sin(theta2[(int)position-10][10]*Pi/180);
                          distance5[i] = sqrt(pow(p_x5[i]-x_target[5],2)+pow(p_y5[i]-y_target[5],2));
                      }
                      else
                      {
                          p_x5[i] = X[4] + 1*cos(theta1[(int)position][10]*Pi/180);
                          p_y5[i] = Y[4] + 1*sin(theta1[(int)position][10]*Pi/180);
                          distance5[i] = sqrt(pow(p_x5[i]-x_target[5],2)+pow(p_y5[i]-y_target[5],2));
                      }
                  }
              }
              position5 = min_element(distance5+1,distance5+1+number)-distance5;
              pos_x[5] = p_x5[(int)position5];
              pos_y[5] = p_y5[(int)position5];
          }
          else
          {
              if(N_5[1] == 1)
              {
                  array_change(4,Distance5);
                  Pos[5][1] = position;
                  Min_Value[5][1] = min_value;
                  if(position > 10)
                  {
                      p_x51 = X[5] + 1*cos(theta2[(int)position-10][4]*Pi/180);
                      p_y51 = Y[5] + 1*sin(theta2[(int)position-10][4]*Pi/180);
                  }
                  else
                  {
                      p_x51 = X[1] + 1*cos(theta1[(int)position][4]*Pi/180);
                      p_y51 = Y[1] + 1*sin(theta1[(int)position][4]*Pi/180);
                  }
              }
              else if(N_5[1] == 2)
              {
                  array_change(7,Distance5);
                  Pos[5][1] = position;
                  Min_Value[5][1] = min_value;
                  if(position > 10)
                  {
                      p_x51 = X[5] + 1*cos(theta2[(int)position-10][7]*Pi/180);
                      p_y51 = Y[5] + 1*sin(theta2[(int)position-10][7]*Pi/180);
                  }
                  else
                  {
                      p_x51 = X[2] + 1*cos(theta1[(int)position][7]*Pi/180);
                      p_y51 = Y[2] + 1*sin(theta1[(int)position][7]*Pi/180);
                  }
              }
              else if(N_5[1] == 3)
              {
                  array_change(9,Distance5);
                  Pos[5][1] = position;
                  Min_Value[5][1] = min_value;
                  if(position > 10)
                  {
                      p_x51 = X[5] + 1*cos(theta2[(int)position-10][9]*Pi/180);
                      p_y51 = Y[5] + 1*sin(theta2[(int)position-10][9]*Pi/180);
                  }
                  else
                  {
                      p_x51 = X[3] + 1*cos(theta1[(int)position][9]*Pi/180);
                      p_y51 = Y[3] + 1*sin(theta1[(int)position][9]*Pi/180);
                  }
              }
              else if(N_5[1] == 4)
              {
                  array_change(10,Distance5);
                  Pos[5][1] = position;
                  Min_Value[5][1] = min_value;
                  if(position > 10)
                  {
                      p_x51 = X[5] + 1*cos(theta2[(int)position-10][10]*Pi/180);
                      p_y51 = Y[5] + 1*sin(theta2[(int)position-10][10]*Pi/180);
                  }
                  else
                  {
                      p_x51 = X[4] + 1*cos(theta1[(int)position][10]*Pi/180);
                      p_y51 = Y[4] + 1*sin(theta1[(int)position][10]*Pi/180);
                  }
              }
              pos_x[5] = p_x51;
              pos_y[5] = p_y51;
          }
}

int LMST::insect(double x1, double y1,double radius1, double x2, double y2, double radius2)
{
   
           double d1=0, a1=0, b1=0, c1=0, p1=0, q1=0, r1=0;  // x = r1 * cosθ + x1, y = r1 * sinθ + y1
           if (double_equals(x1,x2) && double_equals(y1,y2) && double_equals(radius1,radius2))
           {
               return -1;//if two circles have the same center point and radius, return -1
           }

           d1 = distance(x1,y1,x2,y2);  //distance between two center points
           if (d1 > radius1 + radius2 || d1 < fabs(radius1 - radius2)) {
               return 0;//two circles do not have intersection part, return 0
           }
           //(r1*cosθ+x1-x2)^2 + (r1*sinθ+y1-y2)^2=r2^2
           // => (r1*cosθ)^2 + (r1*sinθ)^2 + 2*r1*(x1-x2)*cosθ + 2*r1*(y1-y2)*sinθ = r2^2 - (x1-x2)^2 - (y1-y2)^2
           //a = 2*r1*(x1-x2)   b = 2*r1*(y1-y2)    c = r2^2-r1^2-(x1-x2)^2-(y1-y2)^2
           //=>  a*cosθ+b*sinθ = c     sinθ = (1 - (cosθ)^2)^(1 / 2)
           //=>   p = a^2 + b^2  q = -2 * a * c   r = c^2 - b^2
           //=>   cosθ = (±(q^2 - 4 * p * r)^(1/2) - q) / (2 * p)
           a1 = 2.0 * radius1 * (x1 - x2);
           b1 = 2.0 * radius1 * (y1 - y2);
           c1 = radius2 * radius2 - radius1 * radius1 - distance_sqr(x1,y1,x2,y2);
           p1 = a1 * a1 + b1 * b1;
           q1 = -2.0 * a1 * c1;
        
           if (double_equals(d1, radius1 + radius2) || double_equals(d1, fabs(radius1 - radius2))) {
               cos_value[0] = -q1 / p1 / 2.0;
               sin_value[0] = sqrt(1 - cos_value[0] * cos_value[0]);
               point_x1 = radius1 * cos_value[0] + x1;
               point_y1 = radius1 * sin_value[0] + y1;

               if (!double_equals(distance_sqr(point_x1,point_y1,x2,y2), radius2 * radius2)) {
                   point_y1 = y1 - radius1 * sin_value[0];
               }
               
               angle_x1 = acos(point_x1 - x1)*180/Pi;
               angle_y1 = asin(point_y1 - y1)*180/Pi;
               
               return 1;//only has one root (x0,y0) between two circles, return 1
           }

           r1 = c1 * c1 - b1 * b1;
           cos_value[0] = (sqrt(q1 * q1 - 4.0 * p1 * r1) - q1) / p1 / 2.0;
           cos_value[1] = (-sqrt(q1 * q1 - 4.0 * p1 * r1) - q1) / p1 / 2.0;
           sin_value[0] = sqrt(1 - cos_value[0] * cos_value[0]);
           sin_value[1] = sqrt(1 - cos_value[1] * cos_value[1]);
    
           point_x1 = radius1 * cos_value[0] + x1;
           point_x2 = radius1 * cos_value[1] + x1;
           point_y1 = radius1 * sin_value[0] + y1;
           point_y2 = radius1 * sin_value[1] + y1;
    
           if (!double_equals(distance_sqr(point_x1,point_y1,x2,y2), radius2 * radius2)) {//check the root
               point_y1 = y1 - radius1 * sin_value[0];
           }
           if (!double_equals(distance_sqr(point_x2,point_y2,x2,y2), radius2 * radius2)) {//check the root
               point_y2 = y1 - radius1 * sin_value[1];
           }
           if (double_equals(point_y1, point_y2) && double_equals(point_x1, point_x2)) {//when it has two the same roots
               if (point_y1 > 0) {
                   point_y2 = -point_y2;
               } else {
                   point_y1 = -point_y1;
               }
           }
           
           angle_x1 = acos(point_x1 - x1)*180/Pi;
           angle_y1 = asin(point_y1 - y1)*180/Pi;
           angle_x2 = acos(point_x2 - x1)*180/Pi;
           angle_y2 = asin(point_y2 - y1)*180/Pi;
           angle_x3 = acos(point_x1 - x2)*180/Pi;
           angle_y3 = asin(point_y1 - y2)*180/Pi;
           angle_x4 = acos(point_x2 - x2)*180/Pi;
           angle_y4 = asin(point_y2 - y2)*180/Pi;
    
           angle_change(angle_y1,angle_x1);
           angle_change(angle_y2,angle_x2);
           angle_change(angle_y3,angle_x3);
           angle_change(angle_y4,angle_x4);
           
           angle_max1 = fmax(fmax(fmax(angle_x1,angle_x2),angle_y1),angle_y2);
           angle_min1 = fmin(fmin(fmin(angle_x1,angle_x2),angle_y1),angle_y2);
           angle_max2 = fmax(fmax(fmax(angle_x3,angle_x4),angle_y3),angle_y4);
           angle_min2 = fmin(fmin(fmin(angle_x3,angle_x4),angle_y3),angle_y4);
         
    return 2;//have two intersection points, return 2
}
 
int main()
{
    int number1,number2,number3,number4,number5;
    memset(map,0x3f,sizeof(map));  //initialize memset as 0x3f, it could aviod error.
    //double X[6]={0},Y[6]={0};//x_target[6]={0},y_target[6]={0};
    double x1,y1,x2,y2;
   /* std::default_random_engine e((unsigned)time(0));
    std::uniform_real_distribution<double> u(0.0,1.0);
    for(i=1;i<=5;i++)
    {
        X[i] = u(e);
        Y[i] = u(e);
        x_target[i] = 5+u(e);
        y_target[i] = 5+u(e);
    }
    */
    LMST lmst;
    cout<<fixed<<setprecision(4)<<"x(1)="<<X[1]<<" "<<"x(2)="<<X[2]<<" "<<"x(3)="<<X[3]<<" "<<"x(4)="<<X[4]<<" "<<"x(5)="<<X[5]<<" "<<endl;
    cout<<fixed<<setprecision(4)<<"y(1)="<<Y[1]<<" "<<"y(2)="<<Y[2]<<" "<<"y(3)="<<Y[3]<<" "<<"y(4)="<<Y[4]<<" "<<"y(5)="<<Y[5]<<" "<<endl;
    cout<<fixed<<setprecision(4)<<"x_target(1)="<<x_target[1]<<" "<<"x_target(2)="<<x_target[2]<<" "<<"x_target(3)="<<x_target[3]<<" "<<"x_target(4)="<<x_target[4]<<" "<<"x_target(5)="<<x_target[5]<<" "<<endl;
    cout<<fixed<<setprecision(4)<<"y_target(1)="<<y_target[1]<<" "<<"y_target(2)="<<y_target[2]<<" "<<"y_target(3)="<<y_target[3]<<" "<<"y_target(4)="<<y_target[4]<<" "<<"y_target(5)="<<y_target[5]<<" "<<endl;

    while(sqrt(pow(X[1]-x_target[1],2)+pow(Y[1]-y_target[1],2)) > 0.6 || sqrt(pow(X[2]-x_target[2],2)+pow(Y[2]-y_target[2],2)) > 0.6 || sqrt(pow(X[3]-x_target[3],2)+pow(Y[3]-y_target[3],2)) > 0.6 || sqrt(pow(X[4]-x_target[4],2)+pow(Y[4]-y_target[4],2)) > 0.6 || sqrt(pow(X[5]-x_target[5],2)+pow(Y[5]-y_target[5],2)) > 0.6)
{
    n = 5; m = 8;
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=n;j++)
        {
            d_x=pow(X[i]-X[j],2);
            d_y=pow(Y[i]-Y[j],2);
            weight[i][j]=100*sqrt(d_x+d_y);
            cout<<"weigth("<<i<<","<<j<<")="<<weight[i][j]<<" ";
            if(i!=j)
            {
                map[i][j] = weight[i][j];
                map[j][i] = weight[i][j];
            }
        }
        total[i]=weight[i][1]+weight[i][2]+weight[i][3]+weight[i][4]+weight[i][5];
        cout<<"total("<<i<<") = "<<total[i]<<endl;
    }
    lmst.prim();

    number1 = 0;number2 = 0;number3 = 0;number4 = 0;number5 = 0;
    for(i=1;i<=4;i++)
    {
        if(n_i[i]==1)
        {
            number1 = number1 + 1;
            N_1[number1] = n_i[i];
            M_1[number1] = m_i[i];
        }
        if(n_i[i]==2 || m_i[i]==2)
        {
            number2 = number2 + 1;
            N_2[number2] = n_i[i];
            M_2[number2] = m_i[i];
        }
        if(n_i[i]==3 || m_i[i]==3)
        {
            number3 = number3 + 1;
            N_3[number3] = n_i[i];
            M_3[number3] = m_i[i];
        }
        if(n_i[i]==4 || m_i[i]==4)
        {
            number4 = number4 + 1;
            N_4[number4] = n_i[i];
            M_4[number4] = m_i[i];
        }
        if(m_i[i]==5)
        {
            number5 = number5 + 1;
            N_5[number5] = n_i[i];
            M_5[number5] = m_i[i];
        }
    }
    
    cout<<"x,y,r: "<<endl;
    for(i=1;i<=4;i++)
    {
        for(j=(i+1);j<=5;j++)
        {
                x1 = X[i];y1 = Y[i];
                x2 = X[j];y2 = Y[j];
               switch (lmst.insect(x1,y1,1,x2,y2,1))
                {
                    case -1:
                        cout<<"THE CIRCLES ARE THE SAME"<<endl;
                        break;
                    case 0:
                        cout<<"NO INTERSECTION"<<endl;
                        break;
                    case 1:
                        cout<<fixed<<setprecision(4)<<"point("<<i<<","<<j<<")'s root1: ("<<point_x1<<" "<<point_y1<<")"<<endl;
                        cout<<fixed<<setprecision(3)<<"point("<<i<<","<<j<<")'s angle1: ("<<angle_min1<<" "<<angle_max1<<")"<<endl;
                        break;
                    case 2:
                        cout<<fixed<<setprecision(4)<<"point("<<i<<","<<j<<")'s root1: ("<<point_x1<<" "<<point_y1<<")"<<endl;
                        cout<<fixed<<setprecision(4)<<"point("<<i<<","<<j<<")'s root2: ("<<point_x2<<" "<<point_y2<<")"<<endl;
                        cout<<fixed<<setprecision(3)<<"point("<<i<<","<<j<<")'s angle1: ("<<angle_min1<<" "<<angle_max1<<")"<<endl;
                        cout<<fixed<<setprecision(3)<<"point("<<i<<","<<j<<")'s angle2: ("<<angle_min2<<" "<<angle_max2<<")"<<endl;
                        center_point_x1[i][j] = X[i]; Angle_Max1[i][j] = angle_max1;
                        center_point_y1[i][j] = Y[i]; Angle_Min1[i][j] = angle_min1;
                        center_point_x2[i][j] = X[j]; Angle_Max2[i][j] = angle_max2;
                        center_point_y2[i][j] = Y[j]; Angle_Min2[i][j] = angle_min2;
                
                                   if(Angle_Max1[i][j] - Angle_Min1[i][j] < 180)
                                   {
                                       interval1[i][j] = (Angle_Max1[i][j] - Angle_Min1[i][j])/9;
                                       for(k=1;k<=10;k++)
                                       {
                                           theta1[k][K] = Angle_Min1[i][j] + (k-1)*interval1[i][j];
                                       }
                                   }
                                   else
                                   {
                                       interval1[i][j] = (360+Angle_Min1[i][j] - Angle_Max1[i][j])/9;
                                       for(k=1;k<=10;k++)
                                       {
                                           theta1[k][K] = Angle_Max1[i][j] + (k-1)*interval1[i][j];
                                       }
                                   }
                                   
                                   for(k=1;k<=10;k++)
                                   {
                                       C_X1[k] = center_point_x1[i][j] + 1*cos(theta1[k][K]*Pi/180);
                                       C_Y1[k] = center_point_y1[i][j] + 1*sin(theta1[k][K]*Pi/180);
                                       Distance1[k][K] = sqrt(pow(C_X1[k]-x_target[1],2)+pow(C_Y1[k]-y_target[1],2));
                                       Distance2[k][K] = sqrt(pow(C_X1[k]-x_target[2],2)+pow(C_Y1[k]-y_target[2],2));
                                       Distance3[k][K] = sqrt(pow(C_X1[k]-x_target[3],2)+pow(C_Y1[k]-y_target[3],2));
                                       Distance4[k][K] = sqrt(pow(C_X1[k]-x_target[4],2)+pow(C_Y1[k]-y_target[4],2));
                                       Distance5[k][K] = sqrt(pow(C_X1[k]-x_target[5],2)+pow(C_Y1[k]-y_target[5],2));
                                   }
                                   
                                   if(Angle_Max2[i][j] - Angle_Min2[i][j] < 180)
                                   {
                                       interval2[i][j] = (Angle_Max2[i][j] - Angle_Min2[i][j]-10)/9;
                                       for(k=1;k<=10;k++)
                                       {
                                           theta2[k][K] = Angle_Min2[i][j] + 5 + (k-1)*interval2[i][j];
                                       }
                                   }
                                   else
                                   {
                                       interval2[i][j] = (360 + Angle_Min2[i][j] - Angle_Max2[i][j] - 10)/9;
                                       for(k=1;k<=10;k++)
                                       {
                                           theta2[k][K] = Angle_Max2[i][j] + 5 + (k-1)*interval2[i][j];
                                       }
                                   }
                                   
                                   for(k=1;k<=10;k++)
                                   {
                                       C_X2[k] = center_point_x2[i][j] + 1*cos(theta2[k][K]*Pi/180);
                                       C_Y2[k] = center_point_y2[i][j] + 1*sin(theta2[k][K]*Pi/180);
                                       Distance1[k+10][K] = sqrt(pow(C_X2[k]-x_target[1],2)+pow(C_Y2[k]-y_target[1],2));
                                       Distance2[k+10][K] = sqrt(pow(C_X2[k]-x_target[2],2)+pow(C_Y2[k]-y_target[2],2));
                                       Distance3[k+10][K] = sqrt(pow(C_X2[k]-x_target[3],2)+pow(C_Y2[k]-y_target[3],2));
                                       Distance4[k+10][K] = sqrt(pow(C_X2[k]-x_target[4],2)+pow(C_Y2[k]-y_target[4],2));
                                       Distance5[k+10][K] = sqrt(pow(C_X2[k]-x_target[5],2)+pow(C_Y2[k]-y_target[5],2));
                                   }
                        K = K + 1;
                      }
            }
         }
    
    lmst.pos_number1(number1,p_x,p_y);
    lmst.pos_number2(number2,p_x,p_y);
    lmst.pos_number3(number3,p_x,p_y);
    lmst.pos_number4(number4,p_x,p_y);
    lmst.pos_number5(number5,p_x,p_y);
   
    for(i=1;i<=5;i++)
    {
        for(j=1;j<=5;j++)
        {
            r[i][j] = sqrt(pow(p_x[i]-p_x[j],2)+pow(p_y[i]-p_y[j],2));
        }
        if(r[i][1]<1 && r[i][2]<1 && r[i][3]<1 && r[i][4]<1 && r[i][5]<1)
        {
            X[i] = p_x[i];
            Y[i] = p_y[i];
        }
        else
        {
            X[i] = X[i] + 0.5*(p_x[i]-X[i]);
            Y[i] = Y[i] + 0.5*(p_y[i]-Y[i]);
        }
    }
    K = 1;
}
    return 0;
}
